#!/bin/bash

rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: -4.0
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 0.0"

rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 0.0
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 1.57"

rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 4.0
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 0.0"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 0.0
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: -1.57"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 3.14
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: -3.14"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 0.0
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 2.356"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 2.82842
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 0.0"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 0.0
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 0.7854"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 2.0
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 0.0"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 12.56
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 6.28"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 3.0
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 0.0"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 3.14
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 3.14"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 3.14
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: -3.14"
 
  rostopic pub -1 /turtle1/cmd_vel geometry_msgs/Twist "linear:
  x: 1
  y: 0.0
  z: 0.0
angular:
  x: 0.0
  y: 0.0
  z: 0.0" 

