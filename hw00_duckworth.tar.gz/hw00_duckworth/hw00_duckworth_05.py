print('Problem 05 - Sorting values min to max')
a = float(input('Please enter the first number:'))
b = float(input('Please enter the second number: '))

x = min(a,b)
y = max(a,b)

print('The values sorted smallest to largest: ', x,y)

