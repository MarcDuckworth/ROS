import math
print('Problem 03 - Modulo Division')
dividend = input('Please enter a dividend: ')
divisor = input('Please enter a divisor: ')

x = float(dividend)//float(divisor)
y = float(dividend)%float(divisor)

print('Dividend/Divisor -->', x)
print('Remainder is : ', y)
