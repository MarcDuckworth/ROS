print('Problem 07 - Print first and last name')
first_name = str(input('Input your first name: '))
last_name = str(input('Input your last name: '))
print('Your name is: ',first_name, last_name)
                
