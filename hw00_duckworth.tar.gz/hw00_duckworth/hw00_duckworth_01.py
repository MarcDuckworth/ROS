print('Problem 01 - Add two integers')

num_1 = input('Enter the first integer: ')
num_2 = input('Enter the second integer: ')

sum = int(num_1) + int(num_2)

print('The sum of two integers is:', sum)
