print('Problem 06 - Characters in a string')

a = str(input('Enter a string: '))
print('The length of the string is: ', len(a))
        
