import cmath
print('Problem 04 - Computing roots of Quadratic Eqn')
a = float(input('Please input value for a: '))
b = float(input('Please input value for b: '))
c = float(input('Please input value for c: '))

print('Values inputed for a,b,c: ', a,b,c)


under_root= (b**2)-(4*a*c)

root_1 = (-b+cmath.sqrt(under_root))/(2*a)
root_2 = (-b-cmath.sqrt(under_root))/(2*a)

print('The roots are: ', root_1,root_2)
