print('Problem 10 - Creating list with step size of 1')
a = int(input('Input the first integer: ' ))
b = int(input('Input the second integer: '))
print(a,b)

if(a>=b):
    print('Select a number bigger than the first integer')

else:
    int_list = []

    while (a<b+1):
        int_list.append(a)
        a += 1
        print(int_list)
