print('Problem 09 - Even and Odd indices')
integer_list = [0,1,2,3,4,5,6,7,8,9]
print(integer_list)

evenind = []
oddind = []

for i in range(0, len(integer_list)):
    if i % 2==0:
        evenind.append(i)
    else:
        oddind.append(i)
print('Even indice values: ', evenind)
print('Odd indice values: ', oddind)
