import random
print('Problem 08 - Sorting random integers')
rand_list = []

n = 3

for i in range(n):
    rand_list.append(random.randint(0,9))

print(rand_list)
print('Min value: ', min(rand_list))
print('Max value: ', max(rand_list))
