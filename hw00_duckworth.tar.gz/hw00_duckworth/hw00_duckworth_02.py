import math
dir(math)
print('Problem 02 - Calculating volume of a cylinder')
r = input('Enter radius of the cylinder: ')
h = input('Enter height of the cylinder: ')

volume = float(math.pi)*float(r)*float(r)*float(h)

print('The volume of the cylinder is:', volume) 
