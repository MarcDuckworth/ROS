#!/usr/bin/env python3

# Import base ROS
import rospy

# Import OpenCV and NumPy
import cv2 as cv
import numpy as np

# Import ROS message information
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from sensor_msgs.msg import LaserScan


# Import dynamic reconfigure 
from dynamic_reconfigure.server import Server
from hw09_duckworth.cfg import LidarParamsDynCfgConfig


####################################
# CenterRobotNode class definition
####################################
class CenterRobotNode():
    def __init__(self):
        """Speed control node"""

        # Initialize dynamic reconfigure
        self.enable = False
        self.record_max = False
        self.window = 2
        self.max_error = 0.0
        

        # Initialize speed
        self.speed = 0.0

        #Proportinal Constant
        self.K = 3.0
      
        # Define the lidar subscriber
        self.lidar_sub = rospy.Subscriber('scan', LaserScan ,
                                          self.scan_callback, queue_size=1)
        
        # Define 'cmd_vel' publisher
        self.pub_vel= rospy.Publisher('cmd_vel', Twist, queue_size=1)

        # Set up dynamic reconfigure
        self.srv = Server(LidarParamsDynCfgConfig,
                          self.dyn_reconfig_callback)

        # Define ROS rate
        self.rate = rospy.Rate(20)  # Vehicle rate

        # Loop and publish commands to vehicle
        while not rospy.is_shutdown():

            # Build message speed and yaw rate message and publish
            if (self.enable == 1):
                msg = Twist()
                if (self.record_max and self.error > self.max_error):
                    self.max_error = self.error
                    rospy.loginfo('Max Error: %.2f:' % (self.max_error))

                msg.linear.x = self.K*self.error
                self.pub_vel.publish(msg)
                #rospy.loginfo('Publishing cmd_vel linear: %.2f:' % msg.linear.x)
            else:
            # Stop robot if not enabled
                msg = Twist()
                msg.linear.x = 0.0
                self.pub_vel.publish(msg)
                # Sleep for time step
                self.rate.sleep()
            
        return


    ################################
    # Dynamic Reconfigure callback
    ################################
    def dyn_reconfig_callback(self, config, level):
        self.enable = config['enable']
        self.record_max = config['record_max']
        self.window = config['window']
        print(config)
        return config
        

    #########################
    # Camera image callback
    #########################
    def scan_callback(self, data):

        min_idx_l = None
        min_idx_r = None
        min_dist_r = data.range_max
        min_dist_l = data.range_max
        idx = 0
        idx2 = 180
        #for idx in range(0, (self.window / 2) + 1):
        if(data.ranges[idx] > data.range_min and
           data.ranges[idx] < min_dist_r):
            min_idx_r = idx
            min_dist_r = data.ranges[idx]


        #if( min_idx_r is not None ):
            #rospy.loginfo('Closest Obj right at and dist = %.3f' % (min_dist_r) )


        ##for idx2 in range(180, (self.window / 2) + 1):
        if(data.ranges[idx2] > data.range_min and
           data.ranges[idx2] < min_dist_l):
            min_idx_l = idx2
            min_dist_l = data.ranges[idx2]
                
        #if( min_idx_l is not None ):
            #rospy.loginfo('Closest Obj left and dist = %.3f' % ( min_dist_l ))

        self.error = min_dist_r - min_dist_l
        #rospy.loginfo('Error = %.3f' % ( self.error))

        return
      
        


#################    
# Main function
#################
if __name__ == '__main__':
    
    # Initialize the node and name it.
    rospy.init_node('center_robot_node')
    print("Center Robot node initialized")
    
    # Start node
    try:
        CenterRobotNode()
    except rospy.ROSInterruptException:
        pass
