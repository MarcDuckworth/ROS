#!/usr/bin/env python3

# Import base ROS
import rospy

# Import OpenCV and NumPy
import cv2 as cv
import numpy as np

# Import ROS message information
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from sensor_msgs.msg import LaserScan


# Import dynamic reconfigure 
from dynamic_reconfigure.server import Server
from hw09_duckworth.cfg import LidarParamsDynCfgConfig


####################################
# CenterRobotNode class definition
####################################
class CenterRobotNode():
    def __init__(self):
        """Speed control node"""

        # Initialize dynamic reconfigure
        self.enable = False
        self.record_max = False
        self.window = 0.0
        

        # Initialize speed
        self.speed = 0.0

        #Proportinal Constant
        #self.K = 1.0
      
        # Define the lidar subscriber
        self.lidar_sub = rospy.Subscriber('scan', LaserScan ,
                                          self.scan_callback, queue_size=1)
        
        # Define 'cmd_vel' publisher
        self.pub_vel= rospy.Publisher('cmd_vel', Twist, queue_size=1)

        # Set up dynamic reconfigure
        self.srv = Server(LidarParamsDynCfgConfig,
                          self.dyn_reconfig_callback)

        # Define ROS rate
        self.rate = rospy.Rate(20)  # Vehicle rate

        # Loop and publish commands to vehicle
        while not rospy.is_shutdown():

            # Build message speed and yaw rate message and publish
            if (self.enable == 1):
                msg = Twist()
                #msg.linear.x = K*error
                self.pub_vel.publish(msg)
                rospy.loginfo('Publishing cmd_vel linear: %.2f:' % msg.linear.x)
            else:
            # Stop robot if not enabled
                msg = Twist()
                msg.linear.x = 0.0
                self.pub_vel.publish(msg)
                # Sleep for time step
                self.rate.sleep()
            
        return


    ################################
    # Dynamic Reconfigure callback
    ################################
    def dyn_reconfig_callback(self, config, level):
        self.enable = config['enable']
        self.record_max = config['record_max']
        self.window = config['window']
        print(config)
        return config
        

    #########################
    # Camera image callback
    #########################
    def scan_callback(self, data):

        min_idx = None
        min_dist = data.range_max
        for idx in range(len(data.ranges)):
            if(data.ranges[idx] > data.range_min and
               data.ranges[idx] < min_dist):
                min_idx = idx
                min_dist = data.ranges[idx]


        if( min_idx is not None ):
            rospy.loginfo('Closest Obj at %.2f deg and dist = %.3f' % (
                min_idx*data.angle_increment*180/np.pi, min_dist ))

            return
      
        


#################    
# Main function
#################
if __name__ == '__main__':
    
    # Initialize the node and name it.
    rospy.init_node('center_robot_node')
    print("Center Robot node initialized")
    
    # Start node
    try:
        CenterRobotNode()
    except rospy.ROSInterruptException:
        pass
