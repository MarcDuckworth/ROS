import rospy
import rosbag
import matplotlib.pyplot as plt
import numpy as np


# loading center line data
centerline = np.genfromtxt("center.csv", delimeter=",")


# Define the rosbag
title_str = 'Zig Zag (v = 0.5 m/s, k = 1.0)'
bag = rosbag.Bag('2023-03-30-19-52-51.bag')

# Initialize storage
x_pos = []
y pos = []


# Parse rosbag
for topic, msg, t in bag.read_messages(topics=['odom']):
    if topic == 'odom':        
        x_pose.append(msg.pose.pose.position.x)
        y_pose.append(msg.pose.pose.position.y)
       

bag.close()

# Convert arrays to NumPy
x_pos = np.array(x_pos)
y_pos = np.array(y_pos)


# Plot

plt.figure()
plt.plot(centerline[:,0], centerline[:,1],'.',markersize =1, label='Center Line')
plt.plot(x_pos, y_pos, '.',markersize =1, label='Robot Path')
plt.title(title_str)
plt.xlabel('X(m)')
plt.ylabel('Y(m)')
ax = plt.gca()
ax.set_aspect('equal', adjustable = 'box')
plt.show()

