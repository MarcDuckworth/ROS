print('Problem 01 - Computing cross product of two vectors')

import numpy as np

a = [1,2,3]
b = [3,-2,2]
def cross(a,b):

    a = [1,2,3]
    b = [3,-2,2]

    c = [a[1]*b[2] - a[2]*b[1],
        a[2]*b[0] - a[0]*b[2],
        a[0]*b[1] - a[1]*b[0]]
    return c


Vector_a = np.array([1,2,3])
Vector_b = np.array([3,-2,2])

print('a = ',Vector_a)
print('b = ',Vector_b)

print('a x b = ',cross(a,b))

print('a x b = ',np.cross(Vector_a,Vector_b))



