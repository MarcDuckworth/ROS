import matplotlib.pyplot as plt
import numpy as np
import math 

print('Problem 04 - Rounding')
x = np.arange(0,5.0,.01)


plt.title('Graph of functions')
plt.xlabel('X')
plt.ylabel('Y')

plt.plot(x,np.round(x),'r-',label = 'rounded')
plt.plot(x,np.ceil(x),'k-',label = 'ceiling')
plt.plot(x,np.floor(x),'b-',label = 'floor')
plt.legend()
plt.show()
