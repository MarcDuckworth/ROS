import numpy as np
from numpy import e, pi, sin, exp, cos
import matplotlib.pyplot as plt

print('Problem 03 - Subplots')
 
def f(x):
    return x

def fa(x):
    return 1-x
def fb(x):
    return x**(2)

def fc(x):
    return e**(x)


python_course_green = "#476042"
fig = plt.figure(figsize=(6, 4))

x = np.arange(0, 1.0, 0.1)

sub1 = fig.add_subplot(221) 
sub1.set_title('Y = X') 
sub1.plot(x, f(x))


sub2 = fig.add_subplot(222)
sub2.set_title('Y = 1-X')
sub2.plot(x, fa(x))


sub3 = fig.add_subplot(223)
sub3.set_title('Y = X^2')
sub3.plot(x, fb(x))

sub4 = fig.add_subplot(224)
sub4.set_title('Y = e^x')
sub4.plot(x, fc(x))


plt.tight_layout()
plt.show()

