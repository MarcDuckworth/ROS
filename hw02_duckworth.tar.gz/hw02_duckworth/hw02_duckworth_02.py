import matplotlib.pyplot as plt
import numpy as np

x_min = float(input('Enter x_min: '))
x_max = float(input('Enter x_max: '))
step = float(input('Enter dx: '))

t= np.arange(x_min, x_max, step)

x = np.sin(2*np.pi*t)
y = np.cos(2*np.pi*t)
plt.plot(t,x,'r-',t,x,'ro',t,y,'k--')
plt.xlabel('X range')
plt.ylabel('Y range')
plt.show()
