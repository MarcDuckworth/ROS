import matplotlib.pyplot as plt
import numpy as np

print('Problem 05 - Numerical vs. Symbolic Integration')

x = np.arange(0,5,.1)
f = x**2-6*x+4
integral = ((x**3/3)-3*x**2+4*x)


def trapezoid(x_min, x_max, dx):

    x0 = np.arange(x_min, x_max, dx)
    f0 = x0**2-6*x0+4
    y0 = [0]*len(x0)

    for i in range(len(x0)-1):

        x0[i] = dx/2*(f0[i])
       
    return x0,f0,y0

   


x_trap,y_trap,f_trap = trapezoid(0,5,.5)

plt.subplot(1,2,1)
plt.xlabel('x')
plt.ylabel('y')
plt.title('y(x)')
main_g = plt.plot(x,f,'b')


plt.subplot(1,2,2)
plt.xlabel('x')
plt.ylabel('y')
plt.title('Integral dx = .5')
support_g = plt.plot(x,integral,'k')
second_g = plt.plot(x_trap,y_trap,'r--')
plt.legend(['Symbolic','Numerical'], loc = "upper right")
plt.show()

x_trap,y_trap,f_trap = trapezoid(0,5,.1)

plt.subplot(1,2,1)
plt.xlabel('x')
plt.ylabel('y')
plt.title('y(x)')
main_g = plt.plot(x,f,'b')


plt.subplot(1,2,2)
plt.xlabel('x')
plt.ylabel('y')
plt.title('Integral dx = .1')
support_g = plt.plot(x,integral,'k')
second_g = plt.plot(x_trap,y_trap,'r--')
plt.legend(['Symbolic','Numerical'], loc = "upper right")
plt.show()

x_trap,y_trap,f_trap = trapezoid(0,5,.001)

plt.subplot(1,2,1)
plt.xlabel('x')
plt.ylabel('y')
plt.title('y(x)')
main_g = plt.plot(x,f,'b')

plt.subplot(1,2,2)
plt.xlabel('x')
plt.ylabel('y')
plt.title('Integral dx = .001')
support_g = plt.plot(x,integral,'k')
second_g = plt.plot(x_trap,y_trap,'r--')
plt.legend(['Symbolic','Numerical'], loc = "upper right")
plt.show()


