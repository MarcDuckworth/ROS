import rospy
import rosbag
import matplotlib.pyplot as plt
import numpy as np

# Define the rosbag
bag = rosbag.Bag('2023-03-30-19-52-51.bag')

# Initialize storage
x_time = []
x_odom = []

vel_time = []
vel_vel = []

# Parse rosbag
for topic, msg, t in bag.read_messages(topics=['odom', 'cmd_vel']):
    if topic == 'odom':        
        x_time.append(t.to_sec())
        x_odom.append(msg.pose.pose.position.x)
       
    
    if topic == 'cmd_vel':
        vel_time.append(t.to_sec())
        vel_vel.append(msg.linear.x)

bag.close()

# Convert arrays to NumPy
x_time = np.array(x_time)
x_odom = np.array(x_odom)
vel_time = np.array(vel_time)
vel_vel = np.array(vel_vel)

# Min time
min_t = min(x_time[0], vel_time[0])
x_time -= min_t
vel_time -= min_t
plt.figure()
plt.plot(x_time, x_odom, label='Position')
plt.plot(vel_time, vel_vel, label='Velocity')
plt.title('Position and Velocity vs Time')
plt.xlabel('Time (s)')
plt.ylabel('Disance (m)/ Velocity (m/s)')
plt.legend()
plt.show()

#Cross Plot
vel_vel_interp = np.interp(x_time, vel_time, vel_vel)
plt.figure()
plt.plot(x_odom, vel_vel_interp)
plt.title('Speed vs. Postion')
plt.xlabel('Position (m)')
plt.ylabel('Speed (m/s)')
plt.show()
