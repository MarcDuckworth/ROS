import rospy
import rosbag
import matplotlib.pyplot as plt
import numpy as np

# Define the rosbag
bag = rosbag.Bag('2023-04-20-22-28-06.bag')

# Initialize storage
x_time = []
x_odom = []
x_odom_circ0 = []
x_odom_circ1 = []
x_time_circ0 = []
x_time_circ1 = []
# Parse rosbag
for topic, msg, t in bag.read_messages(topics=['circ0_loc', 'circ1_loc', 'odom']):

    if topic == 'circ0_loc':        
        x_time_circ0.append(t.to_sec())
        x_odom_circ0.append(msg.data)
    
    if topic == 'circ1_loc':
        x_time_circ1.append(t.to_sec())
        x_odom_circ1.append(msg.data)
       
    if topic == 'odom':
        x_time.append(t.to_sec())
        x_odom.append(msg.pose.pose.position.x)
bag.close()

# Convert arrays to NumPy
x_time = np.array(x_time)
x_odom = np.array(x_odom)
x_time_circ0 = np.array(x_time_circ0)
x_odom_circ0 = np.array(x_odom_circ0)
x_time_circ1 = np.array(x_time_circ1)
x_odom_circ1 = np.array(x_odom_circ1)
#x_circ0 = np.interp(t_


# Min time
min_t = min(x_time[0], x_time_circ0[0], x_time_circ1[0])
x_time -= min_t
x_time_circ0 -= min_t
x_time_circ1 -= min_t

plt.figure()
plt.plot(x_time_circ0, x_odom_circ0, label='Circle 0')
plt.plot(x_time_circ1, x_odom_circ1, label='Circle 1')
plt.plot(x_time, x_odom, label='Robot')
plt.title('K = 3.0, Max Error = .17')
plt.xlabel('Time (s)')
plt.ylabel('X(m)')
plt.legend()
plt.show()

#Cross Plot
min_t = min(x_time[0], x_time_circ0[0], x_time_circ1[0])
x_time -= min_t
x_time_circ0 -= min_t
x_time_circ1 -= min_t
Right_dist = x_odom_circ0[:len(x_odom)] - x_odom
Left_dist = x_odom - x_odom_circ1[:len(x_odom)]
position_err = Right_dist - Left_dist
plt.figure()
plt.plot(x_odom, position_err)
plt.title('Position Error vs. Time')
plt.xlabel('Time(s)')
plt.ylabel('Position Error(m)')
plt.show()
