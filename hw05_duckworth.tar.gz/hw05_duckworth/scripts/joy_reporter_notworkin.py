#!/usr/bin/env python3

# Import base ROS
import rospy

# Import os
import os

# Import ROS message information
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Joy

############################
# JoyReporter class definition
############################
class JoyReporterNode():
    def __init__(self):
        """Joystick reporter node"""

        # Setup joystick (defaults)
        self.speed_axis_id = 4
        self.yaw_axis_id = 0
        self.speed_inc_button_id = 3
        self.speed_dec_button_id = 0
        self.yaw_rate_inc_button_id = 1
        self.yaw_rate_dec_button_id = 2
        self.speed_delta = 0.25
        self.yaw_rate_delta = 0.25
        self.speed_max = 1.0
        self.yaw_rate_max = 1.0
        self.speed_min = 0
        self.yaw_rate_min = 0
        
        

        # Get parameters
        if rospy.has_param('/joy_reporter_node/speed_axis'):
            self.speed_axis_id = rospy.get_param('/joy_reporter_node/speed_axis')
            
        if rospy.has_param('/joy_reporter_node/steer_axis'):
            self.steer_axis_id = rospy.get_param('/joy_reporter_node/steer_axis')

        if rospy.has_param('/joy_reporter_node/yaw_axis'):
            self.yaw_axis_id = rospy.get_param('/joy_reporter_node/yaw_axis')

        if rospy.has_param('/joy_reporter_node/speed_inc_button'):
            self.speed_inc_button_id = rospy.get_param('/joy_reporter_node/speed_inc_button')

        if rospy.has_param('/joy_reporter_node/speed_dec_button'):
            self.speed_dec_button_id = rospy.get_param('/joy_reporter_node/speed_dec_button')

        if rospy.has_param('/joy_reporter_node/yaw_rate_inc_button'):
            self.yaw_rate_inc_button_id = rospy.get_param('/joy_reporter_node/yaw_rate_inc_button')
        
        if rospy.has_param('/joy_reporter_node/yaw_rate_dec_button'):
            self.yaw_rate_dec_button_id = rospy.get_param('/joy_reporter_node/yaw_rate_dec_button')

        if rospy.has_param('/joy_reporter_node/speed_delta'):
            self.speed_delta = rospy.get_param('/joy_reporter_node/speed_delta')

        if rospy.has_param('/joy_reporter_node/yaw_rate_delta'):
            self.yaw_rate_delta = rospy.get_param('/joy_reporter_node/yaw_rate_delta')

        if rospy.has_param('/joy_reporter_node/speed_max'):
            self.speed_max = rospy.get_param('/joy_reporter_node/speed_max')

        if rospy.has_param('/joy_reporter_node/speed_min'):
            self.speed_min = rospy.get_param('/joy_reporter_node/speed_min')

        if rospy.has_param('/joy_reporter_node/yaw_rate_max'):
            self.yaw_rate_max = rospy.get_param('/joy_reporter_node/yaw_rate_max')
        
        if rospy.has_param('/joy_reporter_node/yaw_rate_min'):
            self.yaw_rate_min = rospy.get_param('/joy_reporter_node/yaw_rate_min')
        ##
        ## Repeat get_param for remaining joystick mapping
        ##
        

        # Define joystick subscriber
        self.sub_joy = rospy.Subscriber('joy', Joy,
                                         self.joy_callback, queue_size=1)

        # Define twist publisher
        self.pub_twist = rospy.Publisher('cmd_vel', Twist, queue_size=10)
        ## Define Twist message publisher on 'cmd_vel' topic
     
        # Enter ROS loop
        rospy.loginfo("Joy Reporter Node Initialized")
        rospy.spin()
        
        return


    #####################
    # Joystick Callback
    #####################
    def joy_callback(self, msg):
  	
  	 speed = self.speed_max * msg.axes[self.speed_axis_id]
  	 yaw_rate = self.yaw_rate_max * msg.axes[self.yaw_axis_id]
       
        if msg.buttons[self.speed_inc_button_id]:
            if not self.speed_inc_button_pressed:
                self.speed_max = min(self.speed_max + self.speed_delta, 1.0)
                rospy.loginfo("Maximum speed set to %f m/s", self.speed_max)
            self.speed_inc_button_pressed = True
        else:
            self.speed_inc_button_pressed = False

        if msg.buttons[self.speed_dec_button_id]:
            if not self.speed_dec_button_pressed:
                self.speed_max = max(self.speed_max - self.speed_delta, 0.0)
                rospy.loginfo("Maximum speed set to %f m/s", self.speed_max)
            self.speed_dec_button_pressed = True
        else:
            self.speed_dec_button_pressed = False

        if msg.buttons[self.yaw_rate_inc_button_id]:
            if not self.yaw_rate_inc_button_pressed:
                self.yaw_rate_max = min(self.yaw_rate_max + self.yaw_rate_delta, 1.0)
                rospy.loginfo("Maximum yaw rate set to %f rad/s", self.yaw_rate_max)
            self.yaw_rate_inc_button_pressed = True
        else:
            self.yaw_rate_inc_button_pressed = False

        if msg.buttons[self.yaw_rate_dec_button_id]:
            if not self.yaw_rate_dec_button_pressed:
                self.yaw_rate_max = max(self.yaw_rate_max - self.yaw_rate_delta, 0.0)
                rospy.loginfo("Maximum yaw rate set to %f rad/s", self.yaw_rate_max)
            self.yaw_rate_dec_button_pressed = True
        else:
            self.yaw_rate_dec_button_pressed = False
    # Publish twist message
    twist_msg = Twist()
    twist_msg.linear.x = speed
    twist_msg.angular.z = yaw_rate
    self.cmd_vel_pub.publish(twist_msg)
            
	
#################    
# Main function
#################
if __name__ == '__main__':
    
    # Initialize the node and name it.
    rospy.init_node('joy_reporter_node')
    print("Joy Reporter node initialized")
    
    # Start node
    try:
        JoyReporterNode()
    except rospy.ROSInterruptException:
        pass

       
