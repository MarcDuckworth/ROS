import random

print('Problem 06: Guessing Game')

upper = int(input('Input the maximum value in guess range: '))


x = random.randint(1,upper)

guess = 0

count = 0

while guess != x:
    count += 1

    guess = int(input('Guess a number: '))

    if x == guess:
        print('Correct number', x, 'in', count, 'guesses')
        break

    elif x > guess:
        print('Too low')

    elif x < guess:
        print('Too high')

        
