print('Problem 02 - Computing Sum to 50')

import math

total = 0

for i in range(50):

    while total<50:
        sum_num = int(input('Enter a number: '))
        total += sum_num
        print('The sum is: ',total)
