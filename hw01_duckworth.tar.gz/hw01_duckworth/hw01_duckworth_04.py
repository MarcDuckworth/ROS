import random
list = ['apple', 'orange', 'banana', 'kiwi', 'berry']

n = 5

print(random.choices(list,k=n))
