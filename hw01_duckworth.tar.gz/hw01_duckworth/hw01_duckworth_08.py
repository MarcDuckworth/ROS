print('Problem 08 - Three Squares')
import turtle

color_list = ['red', 'black', 'blue']

for color in color_list:
    turtle.pendown()
    turtle.color(color)

    for i in range(4):
        turtle.forward(100)
        turtle.right(90)

    turtle.penup()
    turtle.forward(150)


input('Press enter to continue')
