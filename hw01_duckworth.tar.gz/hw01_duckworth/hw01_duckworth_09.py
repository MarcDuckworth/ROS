print("Problem 09 - Using Turtle to draw polygon")

import turtle

turtle.pendown()

num_sides = int(input("Enter the number of the sides: "))
length_sides = int(input("Enter the length of the sides: "))

for i in range(num_sides):
   
    turtle.forward(length_sides)
    turtle.right(360/num_sides)
    
