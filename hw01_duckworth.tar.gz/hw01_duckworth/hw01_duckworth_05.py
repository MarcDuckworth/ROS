print("Problem 05 - Random number generator guess")

import random

n = random.randint(1,10)

while(True):
    input_num = int(input("Enter a number between 1 and 10: "))

    if(input_num == n):
        print("Congrats you guessed it!")
    elif(input_num<n):
        print("Too low. Try again!")
    else:
        print("Too high. Try again!")
