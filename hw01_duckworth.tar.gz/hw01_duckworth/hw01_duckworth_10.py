print("Problem 10 - Lowercase to Uppercase")

stringVow = "aeiou"

print("The new uppercase vowels are:", stringVow.upper())
