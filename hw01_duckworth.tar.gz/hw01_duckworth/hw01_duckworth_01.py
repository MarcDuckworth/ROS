
print("Problem 1 - Counting down from user input")
n = int(input("Enter a number below 50: "))
for i in range(n,-1,-1):
        print(i)
