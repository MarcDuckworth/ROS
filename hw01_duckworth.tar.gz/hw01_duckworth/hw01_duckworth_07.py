print('Problem 07 - Divide and Conquer method')

import random
import math


upper = int(input('Input the maximum value in guess range: '))

x = random.randint(1,upper)

print('Random value to guess is', x)

guess = math.ceil(x/2)

count = 0

while guess != x:
    count += 1

    print('Guessing ', guess)

    if x == guess:
        print('Correct number', x, 'in', count, 'guesses')
        break

    elif x > guess:
        print('Too small')

        guess = math.ceil(guess + guess/2)

        round(guess, 0)

    elif x < guess:
        print('Too high')

        guess = math.ceil(guess/2)

    
    elif x < int_guess:
        print('Too high')

        guess = math.ceil(int_guess/2)
