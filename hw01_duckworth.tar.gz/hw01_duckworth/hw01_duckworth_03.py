print("Problem 03 - Enter a number between 10-20")

import random


while (True):
    input_num = int(input("Enter a number between 10 and 20:"))

    if(input_num>=10 and input_num<=20):
        print("Congrats that works!")

    elif(input_num<10):
        print("Too low. Input new value.")
    else:
        print("Too high. Try again")
