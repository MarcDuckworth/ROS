#!/usr/bin/env python3

# Import base ROS
import rospy

# Import ROS message information
from std_msgs.msg import Empty
from std_msgs.msg import Float32

# Random number
import random


#####################################
# RandNumPublisher class definition
#####################################
class RandNumPublisher():
    def __init__(self):
        """Random number publisher node"""

        # Initialize
        self.reset = False
        self.reset_sum = 500.0

        # Define subscribers
        ## 
        ## Add subscriber to 'sum' topic with callback check_sum_callback
        self.sub_sum = rospy.Subscriber('sum',Float32,
                                        self.check_sum_callback, 
                                        queue_size=1)
        
        # Define publishers
        self.pub_rand_num = rospy.Publisher('rand_num',
                                         Float32, queue_size=1)

        self.pub_reset = rospy.Publisher('reset_sum',
                                         Empty, queue_size=1)

        ##
        ##  

        # Define ROS rate
        self.rate = rospy.Rate(1)

        # Loop and publish commands to vehicle
        while not rospy.is_shutdown():

            # Generate random number and build message
            rand_num = random.uniform(1.0,100.0)
            ## Add msg creation and publishing
            msg = Float32()
            msg.data = rand_num
            self.pub_rand_num.publish(msg)
            rospy.loginfo('Random Number is: %d' %msg.data)
            # Sleep for time step
            self.rate.sleep()
            
        return

    ##########################
    # Set Check Sum Callback
    ##########################
    def check_sum_callback(self, msg):
        ##
        ## Add
        ## 1) rospy.loginfo of the sum returned by the sum node
        #rospy.loginfo('Sum is equal to: %d' %msg.data)
        ## 2) Check sum against 500.0 and publish reset message
        if msg.data > self.reset_sum:    
            msg_out = Empty()
            self.pub_reset.publish(msg_out)
        ## Reset message
        

        return


#################    
# Main function
#################
if __name__ == '__main__':
    
    # Initialize the node and name it.
    rospy.init_node('random_number_gen_node')
    print("Random number generator node initialized")
    
    # Start node
    try:
        RandNumPublisher()
    except rospy.ROSInterruptException:
        pass
