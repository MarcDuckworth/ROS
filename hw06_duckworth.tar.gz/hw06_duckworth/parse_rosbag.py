import rospy
import rosbag
import matplotlib.pyplot as plt
import numpy as np

# Define the rosbag
bag = rosbag.Bag('2023-02-23-19-41-43.bag')

# Initialize storage
time_odom = []
x_odom = []
y_odom = []

time_zone = []
zone_data = []

# Parse rosbag
for topic, msg, t in bag.read_messages(topics=['/odom', '/zone']):
    if topic == '/odom':        
        time_odom.append(t.to_sec())
        x_odom.append(msg.pose.pose.position.x)
        y_odom.append(msg.pose.pose.position.y)
    
    if topic == '/zone':
        time_zone.append(t.to_sec())
        zone_data.append(msg.data)

bag.close()

# Convert arrays to NumPy
time_odom = np.array(time_odom)
x_odom = np.array(x_odom)
y_odom = np.array(y_odom)

print(time_zone)
zone_marker = [5]*len(time_zone)


time_zone = np.array(time_zone)
zone_data = np.array(zone_data)
x_zone = np.interp(time_zone, time, x)
y_zone = np.interp(time_zone, time, y)

plt.plot(time_odom, x, label='x')
plt.plot(time_odom, y, label='y')
plt.plot(time_zone, x, label='o')
plt.plot(time_zone, x, label='.')

# Plot the robot path
plt.plot(x_odom, y_odom, label='Robot Path' )
plt.xlabel('X (m)')
plt.ylabel('Y (m)')
plt.legend()
ax = plt.gca()
ax.set_aspect('equal', adjustable='box')
plt.show()

# Plot the zone data
plt.plot(time_zone, zone_data, label='Zone Data')
plt.xlabel('Time (s)')
plt.ylabel('Zone')
plt.legend()
plt.show()

