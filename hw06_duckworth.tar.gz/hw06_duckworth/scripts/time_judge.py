#!/usr/bin/env python3

# Import base ROS
import rospy

# Import os
import os

# Import ROS message information
from std_msgs.msg import Int16
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry

##############################
# TimeJudge class definition
##############################
class TimeJudgeNode():
    def __init__(self):
        """Time judge node"""

        # Define zone infomation
        self.zones = [ [ [0.0, 3.0], [1.5, 1.5] ],
                       [ [1.5, 3.0], [3.0, 1.5] ],
                       [ [0.0, 1.5], [1.5, 0.0] ],
                       [ [1.5, 1.5], [3.0, 0.0] ],
                       [ [3.0, 3.0], [6.0, 0.0] ],
                       [ [6.0, 3.0], [7.5, 1.5] ],
                       [ [7.5, 3.0], [9.0, 1.5] ],
                       [ [6.0, 1.5], [7.5, 0.0] ],
                       [ [7.5, 1.5], [9.0, 0.0] ] ]

        # Define timer information
        self.start_time = 0
        self.finish_time = 0
        self.elapsed_time = 0
        self.timer_started = False
        self.entered_zone_8 = False
       

        ##
        ## NEED TO DEFINE self.current_zone self.finish_time
        ##
        self.current_zone = 2
        self.finish_time = None
        
        # Define subscriber to 'odom' of type Odometry -> odom_callback
        self.subscriber = rospy.Subscriber('/odom', Odometry, self.odom_callback)
        # Define publisher to 'zone' of type Int16
        self.publisher = rospy.Publisher('/zone', Int16, queue_size=10)

        # Enter ROS loop
        rospy.spin()
        
        return


    #################
    # Odom Callback
    #################
    #################
    # Odom Callback
    #################
    def odom_callback(self, msg):
        '''Function to
        1) Get the robot location
        2) Monitor the current zone
        3) Publish zone transition (publish zone on correctly zone entry)
        4) Manage and display zone/timer information
        '''
        
        # Find the current zone
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        current_zone = self.find_zone(x,y)
        
        # Publish zone transition (publish zone on correctly zone entry)
        if current_zone != self.current_zone:
            self.current_zone = current_zone
            self.publisher.publish(self.current_zone)
            rospy.loginfo('Entered Zone: {}'.format(self.current_zone))
    
        # Manage and display zone/timer information
        if self.start_time is None:
            if current_zone == 3 and self.in_start_zone(x, y):
                self.start_time = rospy.Time.now()
                rospy.loginfo('Started Timer')
                rospy.loginfo('Current Zone: {}'.format(self.current_zone))
        elif self.finish_time is None:
            if self.in_finish_zone(x, y):
                if current_zone == 8 and self.entered_zone_8:
                    self.finish_time = rospy.Time.now()
                    self.elapsed_time = self.finish_time - self.start_time
                    rospy.loginfo('Stopped Timer')
                    rospy.loginfo('Elapsed Time: {} seconds'.format(elapsed_time.to_sec()))
                elif current_zone == 8:
                    self.entered_zone_8 = True
                    rospy.loginfo('Entered Zone: {}'.format(self.current_zone))
            elif self.entered_zone_8:
                if self.start_time is not None:
                    rospy.loginfo('Timer Started')
                if self.finish_time is not None:
                    rospy.loginfo('Timer Stopped')
            return
        
    #####################
    # find_zone function
    #####################
    def find_zone(self, x, y):
        """Function to determine which zone the robot is in"""
        for i in range(len(self.zones)):
            zone = self.zones[i]
            if zone[0][0] <= x <= zone[1][0] and zone[1][1] <= y <= zone[0][1]:
                return i
        rospy.logerr('Zone not found')
        return 0

    #####################
    # in_finish_zone function
    #####################
    def in_finish_zone(self, x, y):
        """Function to determine if the robot is in the finish zone"""
        if self.current_zone == 8:
            if 7.5 <= x <= 9.0 and 0.0 <= y <= 1.5:
                return True
        return False
    #####################
    # in_start_zone function
    #####################
    def in_start_zone(self, x, y):
        """Function to determine if the robot is in the finish zone"""
        if self.current_zone == 2:
            if 0.0 <= x <= 1.5 and 0.0 <= y <= 1.5:
                return True
        return False


#################    
      
        
# Main function
#################
if __name__ == '__main__':
    
    # Initialize the node and name it.
    rospy.init_node('time_judge_node')
    print("Timer judge node initialized")
    
    # Start node
    try:
        TimeJudgeNode()
    except rospy.ROSInterruptException:
        pass
